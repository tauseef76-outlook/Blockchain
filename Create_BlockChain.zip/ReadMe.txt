How to run???
:- First Execute the program(I am using anaconda/spyder, so Ctrl+Enter).
:- In Postman, select 'GET' request option. Then enter  'http://127.0.0.1:5000/<get_chain> or <mine_block>'

# http://127.0.0.1:5000/:- Got this from flask quick start guide
